<section class="banner-section">
		<div class="main-slider-carousel owl-carousel owl-theme">
            
            <div class="slide" style="background-image: url(images/main-slider/image-1.jpg)">
				<div class="patern-layer-one" style="background-image: url(images/main-slider/pattern-1.png)"></div>
				<div class="patern-layer-two" style="background-image: url(images/main-slider/pattern-2.png)"></div>
				<div class="auto-container">
					
					<!-- Content Column -->
					<div class="content-column">
						<div class="inner-column">
							<div class="patern-layer-three" style="background-image: url(images/main-slider/pattern-3.png)"></div>
							<div class="title">Information Technology Support</div>
							<h1>IT Support<br>for Restaurants, Hotels, Companies & host of others.</h1>
							<div class="text">Our services includes Troubleshooting of Computer, Vaccine Dispenser Machines,<br> POS devices, Outdoor Menu boards, Officer Printers, Installation of CCTVs, .</div>
							<div class="btns-box">
								<a href="#" class="theme-btn btn-style-one"><span class="txt">Learn More</span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>
			
			<div class="slide" style="background-image: url(images/main-slider/image-2.jpg)">
				<div class="patern-layer-one" style="background-image: url(images/main-slider/pattern-1.png)"></div>
				<div class="patern-layer-two" style="background-image: url(images/main-slider/pattern-2.png)"></div>
				<div class="auto-container">
					
					<!-- Content Column -->
					<div class="content-column">
						<div class="inner-column">
							<div class="patern-layer-three" style="background-image: url(images/main-slider/pattern-3.png)"></div>
							<div class="title">Web Development</div>
							<h1>Systemdigits offers <br> custom Website Design Designs</h1>
							<div class="text">We are 100+ professional software engineers with more than <br> 10 years of experience in delivering superior products.</div>
							<div class="btns-box">
								<a href="web-development" class="theme-btn btn-style-one"><span class="txt">Learn More</span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>
			
			<div class="slide" style="background-image: url(images/main-slider/image-3.jpg)">
				<div class="patern-layer-one" style="background-image: url(images/main-slider/pattern-1.png)"></div>
				<div class="patern-layer-two" style="background-image: url(images/main-slider/pattern-2.png)"></div>
				<div class="auto-container">
					
					<!-- Content Column -->
					<div class="content-column">
						<div class="inner-column">
							<div class="patern-layer-three" style="background-image: url(images/main-slider/pattern-3.png)"></div>
							<div class="title">Cybersecurity Support</div>
							<h1>We offer Network vulnerability <br>Scans & Penetration Test</h1>
							<div class="text">We have professional Cybersecurity Experts to help in identifying vulnerabilities.<br></div>
							<div class="btns-box">
								<a href="cybersecurity" class="theme-btn btn-style-one"><span class="txt">Learn More</span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>
			
		</div>
		
	</section>