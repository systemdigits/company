<!-- Sidebar Side -->
<div class="sidebar-side left-sidebar col-lg-4 col-md-12 col-sm-12">
                	<aside class="sidebar sticky-top">
						
						<!-- Services -->
                        <div class="sidebar-widget">
                            <ul class="service-list">
                                <li><a href="web-development"><span class="arrow fa fa-angle-double-right"></span> Web Development</a></li>
                                <li><a href="computer-repair"><span class="arrow fa fa-angle-double-right"></span> Computer Repair</a></li>
                                <li><a href="windows-migration"><span class="arrow fa fa-angle-double-right"></span> Windows Migration</a></li>
                                <li><a href="web-hosting"><span class="arrow fa fa-angle-double-right"></span>Web Hosting</a></li>
                                <li><a href="Networking"><span class="arrow fa fa-angle-double-right"></span>Networking</a></li>
                            </ul>
                        </div>
						
						<!-- Contact Widget -->
						<div class="sidebar-widget contact-widget">
							<div class="widget-content" style="background-image:url(images/resource/service.jpg)">
								<div class="border-layer"></div>
								<div class="icon-box flaticon-phone-call"></div>
								<h4>How Can We Help?</h4>
								<div class="text">If you need any help, please <br> feel free to contact us.</div>
								<ul>
									<li><span class="icon flaticon-call"></span>+1(317)-389-3134</li>
									
								</ul>
							</div>
						</div>
						
					</aside>
				</div>