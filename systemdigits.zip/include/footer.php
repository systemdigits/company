<!-- Call To Action Section -->

	<!-- End Call To Action Section -->
	<!-- End Services Section Two -->
	<!-- Testimonial Section -->
	<section class="testimonial-section">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title">
				<div class="clearfix">
					<div class="pull-left">
						
						<h2>Testimonial<br></h2>
					</div>
					<div class="pull-right">
						<div class="text">Our goal is to make our services affordable for every customer & still retaining the quality of service.</div>
					</div>
				</div>
			</div>
			<div class="testimonial-carousel owl-carousel owl-theme">
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box" style="background-image: url(images/background/pattern-4.png)">
						<div class="upper-box">
							
							<h4>Michael Scott</h4>
							<div class="designation">Scotsdale, Arizona</div>
						</div>
						
						<div class="text">"I am very glad that I gave this new contract to Systemdigits Team. You guys are amazing, & completed my Access Points, Routers, Switches & Wall Jack installation on time. Every n works as it should, I will refer you guys in future projects."</div>
					</div>
				</div>
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box" style="background-image: url(images/background/pattern-4.png)">
						<div class="upper-box">
							<div class="icon">
								
							</div>
							<h4>Touch of Michelles LLC</h4>
							<div class="designation">Abuja, Nigeria</div>
						</div>
						<div class="text">"We have been using Systemdigits bulksms messaging application since 2012 to broadcast SMS messages to our growing customers. We have increased in our customer base. Thank you guys."</div>
					</div>
				</div>
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box" style="background-image: url(images/background/pattern-4.png)">
						<div class="upper-box">
							<div class="icon">
								
							</div>
							<h4>Teens & Nubile Inc</h4>
							<div class="designation">Abuja, Nigeria</div>
						</div>
						<div class="text">"Systemdigits helped us greatly with brand awareness and website design. Thank you guys for such exceptional service and fast response."</div>
					</div>
				</div>
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box" style="background-image: url(images/background/pattern-4.png)">
						<div class="upper-box">
							<div class="icon">
								
							</div>
							<h4>Federal Polytechnic Ileoluji</h4>
							<div class="designation">Ileoluji, Ondo State.</div>
						</div>
						<div class="text">"We host our website with Hostnet Systems hosting platform for a long time now. Thank you guys for the prompt technical support."</div>
					</div>
				</div>
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box" style="background-image: url(images/background/pattern-4.png)">
						<div class="upper-box">
							<div class="icon">
							
							</div>
							<h4>Zaron Cosmetics LLC</h4>
							<div class="designation">Abuja, Nigeria</div>
						</div>
						<div class="text">"We have allocated most of our media and adverts to Systemdigits & they have lived up to the expectation. Our business have improved tremendously."</div>
					</div>
				</div>
				
				<!-- Testimonial Block -->
				<div class="testimonial-block">
					<div class="inner-box" style="background-image: url(images/background/pattern-4.png)">
						<div class="upper-box">
							<div class="icon">
								
							</div>
							<h4>Anthony Bailey, Compucom Inc</h4>
							<div class="designation">Paulsboro, New Jersey</div>
						</div>
						<div class="text">"We are so delighted that all the printer repair & laptop repairs we assigned to Systemdigits were all fixed in time. Thank you guys for all the hard work."</div>
					</div>
				</div>
				
			</div>
			
			<div class="lower-text">More than 5k customers have given a positive feedback. . . </div>
			
		</div>
	</section>
	<!-- End Testimonial Section -->
	

<footer class="main-footer">
		<div class="pattern-layer-one" style="background-image: url(images/background/pattern-7.png)"></div>
		<div class="pattern-layer-two" style="background-image: url(images/background/pattern-8.png)"></div>
		<!--Waves end-->
    	<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!-- Footer Column -->
                            <div class="footer-column col-lg-7 col-md-6 col-sm-12">
                                <div class="footer-widget logo-widget">
								<h5>Information</h5>
									<div class="text">We are the best world Information Technology Company. Providing the highest quality in hardware & Network solutions. About more than 25 years of experience and 1000 of innovative achievements.</div>
									<!-- Social Box -->
									<ul class="social-box">
										<li><a href="https://facebook.com/systemdigits" class="fa fa-facebook-f"></a></li>
										<li><a href="https://www.linkedin.com/company/systemdigits" class="fa fa-linkedin"></a></li>
										<li><a href="https://twitter.com/systemdigits" class="fa fa-twitter"></a></li>
										
									</ul>
								</div>
							</div>
							
							<!-- Footer Column -->
                            <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h5>Quick Links</h5>
									<ul class="list-link">
										<li><a href="networking">LAN/WAN Cable Install</a></li>
										<li><a href="pos-installation">POS Installation</a></li>
										<li><a href="computer-repair">Computer Repair</a></li>
										<li><a href="cybersecurity">Cybersecurity</a></li>
										<li><a href="windows-migration">Windows Migration</a></li>
										<li><a href="web-hosting">Web hosting</a></li>
										<li><a href="web-development">Web Development</a></li>
										<li><a href="drive-through-Menu-install">Menu Board Install</a></li>
										<li><a href="careers">Careers</a></li>
										<li><a href="faq">Frequently Asked Questions</a></li>
									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
					<!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
							
							<!-- Footer Column -->
							<div class="footer-column col-lg-5 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h5>Marketing Tools</h5>
									<ul class="list-link">
										<li><a href="united-states-emails-lists">USA Marketing Emails List</a></li>
										<li><a href="uae-email-database">UAE Marketing Emails</a></li>
										<li><a href="nigeria-email-database">Nigeria Marketing Emails</a></li>
										<li><a href="china-email-database">China Marketing Emails</a></li>
										<li><a href="canadian-emails-lists">Canadian Marketing</a></li>
										<li><a href="germany-email-database">Germany Marketing Emails</a></li>
										<li><a href="india-email-database">India Marketing Emails</a></li>
										<li><a href="australia-email-database">Australia Marketing Emails</a></li>
										<li><a href="world-email-database">World Marketing Emails</a></li>
										
									</ul>
								</div>
							</div>
							
							<!-- Footer Column -->
							<div class="footer-column col-lg-6 col-md-6 col-sm-12">
								<div class="footer-widget contact-widget">
									<h5>Contact Us</h5>
									<ul>
										<li>
											<span class="icon flaticon-placeholder-2"></span>
											<strong>Address</strong>
											6658 Longwoods Cir, Indianapolis, Indiana, USA.
										</li>
										<li>
											<span class="icon flaticon-phone-call"></span>
											<strong>Phone</strong>
											<a href="tel:+1(317)-389-3134">+1(317)-389-3134</a>
										</li>
										<li>
											<span class="icon flaticon-email-1"></span>
											<strong>E-Mail</strong>
											<a href="mailto:support@systemdigits.com">support@systemdigits.com</a>
										</li>
										
									</ul>
								</div>
							</div>

							
							
						</div>

						
					</div>
					
				</div>
			</div>
			
			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<div class="auto-container">
					<div class="row clearfix">
						<!-- Column -->
						<div class="column col-lg-6 col-md-12 col-sm-12">
							<div class="copyright">Copyright © <?php echo date("Y"); ?>. Systemdigits LLC. All Rights Reserved.</div>
						</div>
						<!-- Column -->
						<div class="column col-lg-6 col-md-12 col-sm-12">
							<ul class="footer-nav">
								<li><a href="about-us">About Us</a></li>
								<li><a href="terms">Terms</a></li>
								<li><a href="privacy">Privacy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			
		</div>


		<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/54f844e7bd5fa428704ceedc/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

	</footer>