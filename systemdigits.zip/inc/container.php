<link rel="icon" type="image/png" href="https://coderszine.com/wp-content/themes/v2/cz.png">
</head>
<body class="">
<nav class="navbar navbar-expand-sm bg-light">
  <ul class="navbar-nav">
    <li class="nav-item">
     <a href="http://www.coderszine.com" class="navbar-brand">CODERSZINE.COM</a>
    </li>
    <li class="nav-item">
      <a  class="nav-link" href="http://www.coderszine.com">Home</a>
    </li>    
  </ul>
</nav>
<div class="container" style="min-height:500px;">
<div class=''>
</div>
	